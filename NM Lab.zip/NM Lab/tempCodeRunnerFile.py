# if abs((x2-x1)/x2)<eps:
        # #     break
        # return x0