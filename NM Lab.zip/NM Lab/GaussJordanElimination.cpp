#include <bits/stdc++.h>
#define ll long long
using namespace std;

void orientation(vector<vector<double>> &mat, ll index)
{
    ll r = mat.size(), c = mat[0].size();
    for (ll i = index + 1; i < r; i++)
    {
        if (abs(mat[index][index]) < abs(mat[i][index]))
        {
            for (ll k = 0; k < r + 1; k++)
            {
                swap(mat[i][k], mat[index][k]);
            }
        }
    }
}

void printMatrix(vector<vector<double>> mat)
{
    ll r = mat.size(), c = mat[0].size();
    cout << endl;
    for (ll i = 0; i < r; i++)
    {
        for (ll j = 0; j < c; j++)
        {
            cout << setw(4) << mat[i][j] << "\t";
        }
        cout << endl;
    }
}

int main()
{
#ifndef __debug
    freopen("input.txt", "r", stdin);
    freopen("output.txt", "w", stdout);
#endif
    ll n;
    cout << "Enter the number of equation: ";
    cin >> n;
    cout << endl;
    vector<vector<double>> matrix(n, vector<double>(n + 1));
    cout << "Enter the coeff and constant: " << endl;
    for (ll r = 0; r < n; r++)
    {
        for (ll c = 0; c < n + 1; c++)
        {
            cin >> matrix[r][c];
        }
    }
    for (ll i = 0; i < n; i++)
    {
        orientation(matrix,i);
        double pivot = matrix[i][i];
        for (ll j = i; j < n + 1; j++)
        {
            matrix[i][j] /= pivot;
        }

        for (ll j = i + 1; j < n; j++)
        {
            double pivot1 = matrix[j][i];
            for (ll k = i; k < n + 1; k++)
            {
                matrix[j][k] -= matrix[i][k] * pivot1;
            }
        }
    }

    for (ll i = n - 1; i >= 0; i--)
    {
        for (ll j = i - 1; j >= 0; j--)
        {
            double pivot = matrix[j][i];
            for (ll k = 0; k < n + 1; k++)
            {
                matrix[j][k] -= matrix[i][k] * pivot;
            }
        }
    }
    cout << endl
         << "After performing Gauss Jorder Elimination method the matrix will be:" << endl;
    printMatrix(matrix);
    cout << endl
         << "The unkown variable values of given above equations are: " << endl;
    for (int i = 0; i < n; i++)
    {
        cout << "x" << i + 1 << " = " << matrix[i][n] << endl;
    }

    return 0;
}