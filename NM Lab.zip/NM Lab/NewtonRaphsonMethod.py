deg = int(input("Enter the maximum degree of equation: "))
coeff = []
for i in range(deg+1):
    x = float(input("Enter the value of x power with "+str(deg-i)+": "))
    coeff.append(x)
coeff.reverse()


def derivative(eqn):
    der_eq = []
    for i in range(len(eqn)-1):
        der_eq.append((i+1)*eqn[i+1])
    return der_eq


der_eq = derivative(coeff)


def getFuncValue(x, eqn):
    sum = 0.00
    for i in range(len(eqn)):
        sum += (eqn[i]*pow(x, i))
    return sum


def newTonRaphsonMethod(x1, mx_it, mx_error):
    it = 1
    x2 = float(0.00)
    while (it<=mx_it):
        f1 = getFuncValue(x1, coeff)
        der_f1 = getFuncValue(x1, der_eq)
        x2 = x1-(f1/der_f1)
        f2 = getFuncValue(x2, coeff)
        if (f2 == 0):
            return x2
        elif x2!=0 and abs((x2-x1)/x2) <= mx_error:
            break
        x1 = x2
        it += 1
    return x2


eqnstr = ""
for i, cof in enumerate(coeff):
    if cof < 0:
        eqnstr = str(cof)+str("*x"*i)+eqnstr
    else:
        eqnstr = "+"+str(cof)+str("*x"*i)+eqnstr
if eqnstr[0] == "+":
    eqnstr = eqnstr[1:]
print("\nYour equation is "+eqnstr+"=0")

staringGuess=float(input("Enter the start guess value: "))
mx_error = float(input("Enter the value of tolarance erorr: "))
mx_it=int(input("Enter the maximum iteration: "))
print(newTonRaphsonMethod(-10, 100, mx_error))
