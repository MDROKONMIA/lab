#include <bits/stdc++.h>
#define ll long long
using namespace std;
vector<double> coeff;
double eps = 0.01;

double func(double x, ll deg)
{
    double sum = 0.00;
    for (int i = 0; i <= deg; i++)
    {
        sum += (coeff[i] * pow(x, i));
    }
    return sum;
}

double falsePosition(ll deg, double a, double b)
{
    double c;
    while (true)
    {
        double f2 = func(b, deg);
        double f1 = func(a, deg);
        c = a - (f1 * (b - a) / (f2 - f1));
        double f0 = func(c, deg);
        if (f0 == 0)
            return c;
        else if (f0 * f1 < 0)
        {
            b = c;
        }
        else
        {
            a = c;
        }
        double error = abs((b - a));
        if (error < eps)
            return c;
        it++;
    }
    return c;
}

int main()
{
#ifndef __rokon
    freopen("input.txt", 'r', stdin);
    freopen("output.txt", 'w', stdout);
#endif
    ll deg;
    cout << "Enter maximum degree of equation:";
    cin >> deg;
    coeff.resize(deg + 1);
    cout << "Enter all coefficient of pow of x decending order. If absent then put zero:" << endl;
    for (int i = 0; i <= deg; i++)
        cin >> coeff[deg - i];
    double a, b;
    cout << "Enter the initial guess value a and b" << endl;
    cin >> a >> b;

    if (func(a, deg) * func(b, deg) > 0)
        cout << "Invalid guess and enter valid initial guess the try agin" << endl;
    else
    {
        double res = falsePosition(deg, a, b);
        cout << res << endl;
    }
    return 0;
}