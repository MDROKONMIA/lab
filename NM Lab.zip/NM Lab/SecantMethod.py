deg = int(input("Enter the maximum degree of equation: "))
coeff = []
for i in range(deg+1):
    x = float(input("Enter the value of x power with "+str(deg-i)+": "))
    coeff.append(x)
coeff.reverse()

def getFuncValue(x)->float:
    sum=0.00
    for i in range(deg+1):
        sum+=(coeff[i]*pow(x,i))
    return sum
def SecantMethod(x1:float, x0:float, mx_it:int,eps:float)->float:
    it=1
    x2=0.00
    while(it<=mx_it):
        f1,f0=getFuncValue(x1),getFuncValue(x0)
        x2= ((f1)*(x0)-(f0)*(x1))/((f1)-(f0))
        f2=getFuncValue(x2)
        if f2==0 : return x2
        x1,x0=x2,x1
        if (x1!=0) and abs((x1-x0)/x1)<=eps:
            break
        it+=1
    return x2


eqnstr = ""
for i, cof in enumerate(coeff):
    if cof < 0:
        eqnstr = str(cof)+str("*x"*i)+eqnstr
    else:
        eqnstr = "+"+str(cof)+str("*x"*i)+eqnstr
if eqnstr[0] == "+":
    eqnstr = eqnstr[1:]
print("\nYour equation is "+eqnstr+"=0")

x0=float(input("Enter first initial guess: "))
x1=float(input("Enter the second initial guess: "))
mx_it=int(input("Enter the maximum iteration number: "))
if (getFuncValue(x0)*getFuncValue(x1)>0):
    print("Your initial guess value is ivlaid. Pleas enter valid initial guess and try again.")
else:
    eps=float(input("Enter the maximum tolarance error: "))
    print(SecantMethod(x1, x0, mx_it, eps))
