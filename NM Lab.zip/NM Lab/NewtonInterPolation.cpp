#include <bits\stdc++.h>
#define ll long long
using namespace std;

int main()
{

    ll n;
    cout << "Enter the number of term: ";
    cin >> n;
    vector<double> x(n), y(n);
    cout << "Enter the value of x" << endl;
    for (ll i = 0; i < n; i++)
        cin >> x[i];
    cout << "Enter the corresponding value of f(x)" << endl;
    for (ll i = 0; i < n; i++)
        cin >> y[i];
    double val;
    cout << "Inpu x value at which interpolation is required: ";
    cin >> val;
    cout << endl;

    // Caculate Diffrence table
    vector<vector<double>> difTable(n, vector<double>(n));
    for (int i = 0; i < n; i++)
        difTable[i][0] = y[i];
    for (int i = 1; i < n; i++)
    {
        for (int j = 0; j < n - i; j++)
        {
            difTable[j][i] = (difTable[j + 1][i - 1] - difTable[j][i - 1]) / (x[j + i] - x[j]);
        }
    }
    // display difference table
    cout << "\n Forward Difference  table:" << endl;
    for (int i = 0; i < n; i++)
    {
        cout << setw(4) << x[i] << "\t";
        for (int j = 0; j < n - i; j++)
        {
            cout << setw(4) << difTable[i][j] << "\t";
        }
        cout << endl;
    }

    // calculate forward difference value
    double ForwardAns = 0;
    for (int i = 0; i < n; i++)
    {
        double coeff = difTable[0][i];
        double x_val = 1;
        for (int j = 0; j < i; j++)
        {
            x_val *= (val - x[j]);
        }
        ForwardAns += (coeff * x_val);
    }
    cout<<endl << "Forward interpolated funtion value at x="<<val<<" is ";
    cout << ForwardAns << endl;

    return 0;
}