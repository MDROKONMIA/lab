deg = int(input("Enter the maximum degree of equation:"))
eqn = []
for i in range(deg+1):
    x = float(input("Enter the coefficient of x power "+str(deg-i)+": "))
    eqn.append(x)
eqn.reverse()

print("Enter the initial starting values")
x1=float(input("Enter the value of x1: "))
x2=float(input("Enter the value of x2: "))
eps =float(input("Enter the tolarance error: "))

def func(x):
    sum = 0.00
    for i in range(deg+1):
        sum += (eqn[i]*pow(x, i))
    return sum


def FalsePosMethod(x1, x2):
    while True:
        f1, f2 = func(x1), func(x2)
        x0 = x1-(f1*(x2-x1)/(f2-f1))
        f0 = func(x0)
        if (f0 == 0):
            return x0
        elif (f0*f1 < 0):
            x2 = x0
        else:
            x1 = x0
        # if abs((x2-x1)/x2)<eps:
        #     break
        # return x0


eqnstr = ""
for i, cof in enumerate(eqn):
    if i==0:
        eqnstr=str(cof)+eqnstr
    elif cof>=0:
        eqnstr = "+"+str(cof)+"x^"+str(i)+eqnstr
    else:
        eqnstr = str(cof)+"x^"+str(i)+eqnstr

if eqnstr[0] == "+":
    eqnstr = eqnstr[1:]
print("\nYour equation is "+eqnstr+"=0")

if (func(x1)*func(x2)>0):
    print("Your intial starting guess is wrong. Please enter the right initial starting guess and try agin")
else:
    res=FalsePosMethod(x1,x2)
    print("The root of this equation is :"+str(res))