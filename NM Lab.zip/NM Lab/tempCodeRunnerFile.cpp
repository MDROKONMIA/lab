#ifndef __debug
//     freopen("input.txt", "r", stdin);
//     freopen("output.txt", "w", stdout);
// #endif