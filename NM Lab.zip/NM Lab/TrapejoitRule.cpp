#include <bits\stdc++.h>
#define ll long long

using namespace std;

double getFuncVal(double x)
{
    return 1 / (1 + pow(x, 2));
}

int main()
{

#ifndef __debug
    freopen("input.txt", "r", stdin);
    freopen("output.txt", "w", stdout);
#endif
    double a, b, h;
    cout << "Enter the starting, ending and difference between two term point of integration value:";
    cin >> a >> b >> h;
    cout << endl;

    int n = ceil((b - a) / h);
    cout << n << endl;
    vector<double> x(n + 1), y(n + 1);
    double x_val = 0;
    for (ll i = 0; i <= n; i++)
    {
        x[i] = x_val;
        y[i] = getFuncVal(x_val);
        x_val += h;
    }
    double sum = 0;
    for (ll i = 1; i < n; i++)
    {
        sum += y[i];
    }
    sum *= 2;
    sum += y[0] + y[n];
    sum *= (h / 2);
    cout << "This value for equation 1/(1+x^2) " << endl;
    cout << sum << endl;
}