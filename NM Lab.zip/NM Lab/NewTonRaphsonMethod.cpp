#include <bits/stdc++.h>
#define ll long long

using namespace std;

vector<double> eqn, derivative_eqn;



double func(double x, vector<double> eqn)
{
    double sum=0.0000;
    ll n=eqn.size();
    for(ll i=0; i<n; i++){
        sum+=(eqn[i]*pow(x,i));
    }
    return sum;
   
}
vector<double> getDerivative(vector<double> eqn)
{
    ll n=eqn.size();
    vector<double> res(n);
    for(ll i=0; i<n-1; i++){
        res[i]=(i+1)*eqn[i+1];
    }
    return res;
}

double newTonRaphson(double x1, int it)
{
    int numberIt = 0;
    double x2;
    while (numberIt<=it)
    {
        double f1 = func(x1, eqn);
        double difF1 = func(x1,derivative_eqn);
        x2 = x1 - (f1 / difF1);
        double f2 = func(x2,eqn);
        if (f2 == 0)
            return x2;
        x1 = x2;
        numberIt++;
    }

    return x2;
}

int main()
{

    ll degree;
    printf("Enter the maximum degree of equation: ");
    cin>>degree;
    eqn.resize(degree+1);
    for(ll i=0; i<=degree; i++){
        cout<<"Enter the coefiicient of x power "<<degree-i<<endl;
        cin>>eqn[degree-i];
    }
    derivative_eqn = getDerivative(eqn);
    int x1,mx_it;
    cout<<"Enter the initian guess:"<<endl;
    cin>>x1;
    cout<<"Enter the maximum iteration number:"<<endl;
    cin>>mx_it;
    double res = newTonRaphson(x1, mx_it);
    cout << "The root of equation: "<< res << endl;
    return 0;
}