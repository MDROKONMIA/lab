#include <bits/stdc++.h>
#define ll long long
using namespace std;

int main()
{
    ll n;
    cout << "Enter the number of pair: ";
    cin >> n;
    cout << endl;
    vector<double> x(n), y(n);
    cout << "Enter the value of x:" << endl;
    for (ll i = 0; i < n; i++)
        cin >> x[i];
    cout<<endl << "Enter the corresponding value of f(x):" << endl;
    for (ll i = 0; i < n; i++)
        cin >> y[i];
    double findfor;
    cout<<endl << "Enter the x at which lagrange interpolation is required: ";
    cin>>findfor; cout<<endl;
    double sum = 0;
    for (ll i= 0; i < n; i++)
    {
        double l = 1;
        for (ll j = 0; j < n; j++)
        {
            if (i == j)
                continue;
            l*=(findfor-x[j])/(x[i]-x[j]);
        }
        sum+=y[i]*l;
    }
    cout<<endl<<"Lagrange inpolated function value at x= "<<findfor<<" is "<<sum<<endl;
    return 0;
}