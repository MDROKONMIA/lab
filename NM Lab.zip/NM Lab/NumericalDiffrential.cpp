#include <bits\stdc++.h>
#define ll long long
using namespace std;

int main()
{
#ifndef __debug
    freopen("input.txt", "r", stdin);
    freopen("output.txt", "w", stdout);
#endif

    ll n;
    cout << "Enter the number of term: ";
    cin >> n;
    vector<double> x(n), y(n);
    cout << "Enter the value of x" << endl;
    for (ll i = 0; i < n; i++)
        cin >> x[i];
    cout << "Enter the value of f(x)" << endl;
    for (ll i = 0; i < n; i++)
        cin >> y[i];
    double val;
    cout << "Enter the value: ";
    cin >> val;
    cout << endl;

    // Caculate Diffrence table
    vector<vector<double>> difTable(n, vector<double>(n));
    for (int i = 0; i < n; i++)
        difTable[i][0] = y[i];
    for (int i = 1; i < n; i++)
    {
        for (int j = 0; j < n - i; j++)
        {
            difTable[j][i] = (difTable[j + 1][i - 1] - difTable[j][i - 1]);
        }
    }
    // display difference table
    cout << "\n Forward Difference  table:" << endl;
    for (int i = 0; i < n; i++)
    {
        cout << setw(4) << x[i] << "\t";
        for (int j = 0; j < n - i; j++)
        {
            cout << setw(4) << difTable[i][j] << "\t";
        }
        cout << endl;
    }

    double h = x[1] - x[0];
    // forward difference equation evaluation

    double u=(val-x[0])/h;
    double eqnsum=difTable[0][0], eqnterm=1.0;
    for(int i=1; i<n; i++){
        eqnterm*=(eqnterm*(u-i+1)/i);
        eqnsum+=eqnterm*difTable[0][i];
    }

    cout<<endl<<"Funtion value at x= "<<val<<" is "<<eqnsum<<endl;

    ll idx = 1, point;
    cout << "Enter the derivative point: ";
    cin >> point;
    cout << endl;
    double sum = 0, sign=1, term = 0;
    for (int i = 0; i < n; i++)
    {
        term = sign*difTable[point - 1][i] / idx;
        idx++;
        sum += term;
        sign=-sign;
    }
    cout << endl
         << "Derivative value of funtion at x= "
         << x[point - 1] << " is " << sum / h << endl;

    return 0;
}