#include <bits/stdc++.h>
#define ll long long
using namespace std;

void orientation(vector<vector<double>> &mat, ll index)
{
    ll r = mat.size(), c = mat[0].size();
    for (ll i = index + 1; i < r; i++)
    {
        if (abs(mat[index][index]) < abs(mat[i][index]))
        {
            for (ll k = 0; k < r + 1; k++)
            {
                swap(mat[i][k], mat[index][k]);
            }
        }
    }
}

void printEquation(vector<vector<double>> mat)
{
    ll r = mat.size(), c = mat[0].size();
    cout << endl;
    for (ll i = 0; i < r; i++)
    {
        string eqn = "";
        for (ll j = 0; j < c; j++)
        {
            if (j == c - 1)
            {
                eqn += "= " + to_string(mat[i][j]);
                continue;
            }
            if(mat[i][j]<0)
            {
                eqn += "- " + to_string(mat[i][j]) + "X" + to_string(j + 1) + " ";
            }else{
                eqn += "+ " + to_string(mat[i][j]) + "X" + to_string(j + 1) + " ";
            }
        }
        cout << eqn << endl;
    }
}

int main()
{
#ifndef __debug
    freopen("input.txt", "r", stdin);
    freopen("output.txt", "w", stdout);
#endif
    ll n;
    cout << "Enter the number of equation: ";
    cin >> n;
    cout << endl;
    vector<vector<double>> matrix(n, vector<double>(n + 1));
    cout << "Enter the coeff and constant: " << endl;
    for (ll r = 0; r < n; r++)
    {
        for (ll c = 0; c < n + 1; c++)
        {
            cin >> matrix[r][c];
        }
    }
    cout << endl
         << "Your equation matrix: " << endl;
    printEquation(matrix);

    for (ll i = 0; i < n - 1; i++)
    {

        orientation(matrix, i);

        for (ll j = i + 1; j < n; j++)
        {
            double ratio = matrix[j][i] / matrix[i][i];
            for (ll k = 0; k < n + 1; k++)
            {
                matrix[j][k] -= ratio * matrix[i][k];
            }
        }
    }
    vector<double> res(n);
    /* Backward substitution for discovering values of unknowns */
    for (ll i = n - 1; i >= 0; i--)
    {
        res[i] = matrix[i][n];

        for (ll j = i + 1; j < n; j++)
        {
            if (i != j)
            {
                res[i] = res[i] - matrix[i][j] * res[j];
            }
        }
        res[i] = res[i] / matrix[i][i];
    }

    cout << "\nThe values of unknowns for the above equations:\n";
    for (ll i = 0; i < n; i++)
    {
        cout << "x" << i + 1 << "=" << res[i] << endl;
    }

    return 0;
}