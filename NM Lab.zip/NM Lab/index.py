degree = int(input("Enter maximum degree of equation:"))
eqn = []
for i in range(degree+1):
    x = int(input("Enter the value of coeffient x power "+str(degree-i)+": "))
    eqn.append(x)
eqn.reverse()
print("Enter the start value of x1 and x2")
a = float(input("Enter the value of x1:"))
b = float(input("Enter the value of x2:"))

eps = float(input("Enter the maximum tolarance error: "))


def func(x: int):
    sum = 0.00
    for i in range(degree+1):
        sum += (eqn[i]*pow(x, i))
    return sum


def BisectionMethod(a: float, b: float) -> float:
    temp = 0.000
    while (True):
        temp = (a+b)/2
        if (func(temp) == 0):
            break
        if (func(a)*func(temp) < 0):
            b = temp
        else:
            a = temp
        if b != 0 and abs((b-a)/b) < eps:
            break
    return temp


eqnstr = ""
for i, cof in enumerate(eqn):
    if cof < 0:
        eqnstr = str(cof)+"x^"+str(i)+eqnstr
    else:
        eqnstr = "+"+str(cof)+"x^"+str(i)+eqnstr
if eqnstr[0] == "+":
    eqnstr = eqnstr[1:]
print("\nYour equation is "+eqnstr+"=0")

if (func(a)*func(b)) > 0:
    print("\nYour initial guess is invalid. Enter a valid guesses and try again")
else:
    print("The root of function is "+str(BisectionMethod(a, b)))
