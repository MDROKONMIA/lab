#include <bits/stdc++.h>
using namespace std;

#define nn endl

// function to implement the output of function

double fnc(vector<double> ara, int x, double p)
{
    double sum = 0.00;
    for (int i = 0; i <= x; i++)
    {
        double temp = pow(p, i);
        sum += (ara[i] * temp);
    }
    return sum;
}

void solve()
{
    // input the equation
    cout << "Enter the degree of your equation: " << nn;
    int dg;
    cin >> dg;

    vector<double> ara(dg + 1);
    cout << "Now enter all the co efficient, if absent put a zero" << nn;
    for (int i = 0; i <= dg; i++)
    {
        cin >> ara[dg - i];
    }

    cout << "Enter two initial guess: " << nn;

    double a, b;
    cin >> a >> b;

    double temp = (a + b) / 2;

    while (1)
    {

        if (fnc(ara, dg, a) * fnc(ara, dg, temp) < 0)
        {
            b = temp;
        }
        else
        {
            a = temp;
        }

        temp = (a + b) / 2;

        if ((b - a) / b < 0.000001)
        {
            break;
        }
    }

    cout << fixed << setprecision(3) << temp << nn;
}

int main()
{
    solve();
    return 0;
}
